class ReviewsControllerController < ApplicationController
  def new
    @review = Review.new
  end

  def create
    @review = @restaurant.reviews.build(review_params)
    @review.save
  end
end
